import Groq from 'groq-sdk';

const groq = new Groq({
  apiKey: import.meta.env.VITE_GROQ_API_KEY,
  dangerouslyAllowBrowser: true,
});

/**
 * Analyzes resume text against a job description using Groq's LLM.
 * Returns structured ATS match data.
 *
 * @param {string} resumeText - The full text extracted from the resume (PDF/DOCX)
 * @param {string} jobDescription - The job description text
 * @returns {Promise<{ matchScore: number, skillGaps: { skill: string, match: number }[], recommendations: { title: string, type: string }[] }>}
 */
export async function analyzeResume(resumeText, jobDescription) {
  const systemPrompt = `You are an expert ATS (Applicant Tracking System) analyzer and career coach. 
Analyze the candidate's resume against the job description provided.

Return a JSON object with this exact structure:
{
  "matchScore": <number 0-100>,
  "skillGaps": [
    { "skill": "<skill name>", "match": <number 0-100> }
  ],
  "recommendations": [
    { "title": "<specific actionable recommendation>", "type": "<Resume Edit | Study Plan | Interview Prep>" }
  ]
}

Rules:
- matchScore is the overall percentage match between resume and job description.
- skillGaps should list 5-8 key skills from the job description with a match percentage (how well the candidate's resume demonstrates each skill). Include both strong and weak matches.
- recommendations should be 4-6 specific, actionable items. Type must be one of: "Resume Edit", "Study Plan", or "Interview Prep".
- Be honest and precise. Do not inflate scores.
- Return ONLY valid JSON. No markdown, no code blocks, no extra text.`;

  const completion = await groq.chat.completions.create({
    model: 'qwen/qwen3.8-27b',
    messages: [
      { role: 'system', content: systemPrompt },
      {
        role: 'user',
        content: `RESUME:\n${resumeText}\n\nJOB DESCRIPTION:\n${jobDescription}`,
      },
    ],
    temperature: 0.3,
    max_tokens: 2048,
    response_format: { type: 'json_object' },
  });

  const content = completion.choices[0]?.message?.content;
  if (!content) throw new Error('No response from Groq API');

  try {
    return JSON.parse(content);
  } catch {
    throw new Error('Failed to parse AI analysis response');
  }
}

/**
 * Sends a conversation to the Groq-powered AI career coach.
 *
 * @param {Array<{ role: 'system' | 'user' | 'assistant', content: string }>} messages - The full conversation history
 * @returns {Promise<string>} The assistant's reply
 */
export async function chatWithCoach(messages) {
  const systemMessage = {
    role: 'system',
    content: `You are JobCracker AI, a world-class career coach assistant. You help users with:
- Interview preparation (mock questions, behavioral strategies, technical prep)
- Resume and cover letter optimization
- Salary negotiation tactics
- Career path planning
- Skill development roadmaps

Be concise, actionable, and encouraging. Use a professional yet friendly tone. When giving mock interview questions, tailor them to the specific company and role mentioned. When providing advice, include concrete examples. Keep responses under 500 words unless the user asks for more detail.`,
  };

  const completion = await groq.chat.completions.create({
    model: 'qwen/qwen3.8-27b',
    messages: [systemMessage, ...messages],
    temperature: 0.7,
    max_tokens: 1024,
  });

  return completion.choices[0]?.message?.content || 'Sorry, I could not generate a response.';
}
