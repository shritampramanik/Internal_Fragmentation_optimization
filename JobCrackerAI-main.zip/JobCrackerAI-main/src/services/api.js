const API_BASE = import.meta.env.VITE_API_URL || "/api";

async function request(endpoint, options = {}) {
  const token = localStorage.getItem('token');
  const headers = {};

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  // Don't set Content-Type for FormData (multer needs it auto-set with boundary)
  if (!(options.body instanceof FormData)) {
    headers['Content-Type'] = 'application/json';
  }

  const res = await fetch(`${API_BASE}${endpoint}`, {
    ...options,
    headers: {
      ...headers,
      ...options.headers,
    },
  });

  let data;
  try {
    data = await res.json();
  } catch {
    // Response was not JSON (e.g., HTML error page from Express)
    throw new Error(`Server error (${res.status}): ${res.statusText || 'Unexpected response'}`);
  }

  if (!res.ok) {
    throw new Error(data.message || `Request failed with status ${res.status}`);
  }

  return data;
}

// --- Auth ---
export const registerUser = (name, email, password) =>
  request('/auth/register', {
    method: 'POST',
    body: JSON.stringify({ name, email, password }),
  });

export const loginUser = (email, password) =>
  request('/auth/login', {
    method: 'POST',
    body: JSON.stringify({ email, password }),
  });

export const getMe = () =>
  request('/auth/me');

// --- Guest ---
export const guestAnalyze = (formData) =>
  request('/guest/report', {
    method: 'POST',
    body: formData, // FormData with 'resume' file + 'jobDescription' field
  });

// --- Resume (authenticated) ---
export const uploadResume = (formData) =>
  request('/resume/upload', {
    method: 'POST',
    body: formData, // FormData with 'resume' file
  });

export const getResumeHistory = () =>
  request('/resume/history');

// --- Report (authenticated) ---
export const generateReport = (resumeId, jobDescription) =>
  request('/report/generate', {
    method: 'POST',
    body: JSON.stringify({ resumeId, jobDescription }),
  });

export const getReport = (id) =>
  request(`/report/${id}`);

export const getReportHistory = () =>
  request('/report/history');

// --- User ---
export const getProfile = () =>
  request('/user/profile');

export const updateProfile = (data) =>
  request('/user/profile', {
    method: 'PUT',
    body: JSON.stringify(data),
  });
