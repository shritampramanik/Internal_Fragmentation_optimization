const Button = ({ children, variant = 'primary', className = '', onClick, icon: Icon, disabled, type = 'button' }) => {
  const baseStyle =
    'inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl font-semibold text-sm transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed focus:outline-none focus-visible:ring-2 focus-visible:ring-primary/30 focus-visible:ring-offset-2 focus-visible:ring-offset-background';

  const variants = {
    primary: 'bg-foreground text-background hover:bg-foreground/90 shadow-sm',
    secondary: 'bg-white border border-border text-foreground hover:border-border-strong hover:bg-surface-2 shadow-sm',
    glow: 'bg-primary text-white hover:bg-primary-hover shadow-sm shadow-primary/20',
    subtle: 'bg-surface-2 text-foreground-2 hover:text-foreground hover:bg-surface',
    danger: 'bg-danger text-white hover:bg-red-600 shadow-sm shadow-danger/20',
    ghost: 'text-foreground-2 hover:text-foreground hover:bg-surface-2',
  };

  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      className={`${baseStyle} ${variants[variant]} ${className}`}
    >
      {Icon && <Icon className="w-4 h-4" />}
      <span>{children}</span>
    </button>
  );
};

export default Button;
