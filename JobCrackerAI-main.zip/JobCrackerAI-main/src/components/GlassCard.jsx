const GlassCard = ({ children, className = '', hover = false, onClick, ...rest }) => (
  <div
    onClick={onClick}
    className={[
      'card rounded-2xl',
      hover && onClick
        ? 'cursor-pointer hover:shadow-lg hover:-translate-y-0.5 hover:border-slate-300'
        : '',
      className,
    ].filter(Boolean).join(' ')}
    {...rest}
  >
    {children}
  </div>
);

export default GlassCard;
