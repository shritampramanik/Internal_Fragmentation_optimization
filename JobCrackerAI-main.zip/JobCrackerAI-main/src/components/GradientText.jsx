const GradientText = ({ children, className = '' }) => (
  <span
    className={`font-bold bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent ${className}`}
  >
    {children}
  </span>
);

export default GradientText;
