import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { FileText, Plus, ArrowRight } from 'lucide-react';
import GlassCard from '../components/GlassCard';
import Button from '../components/Button';
import { getReportHistory } from '../services/api';

const ReportsList = () => {
  const navigate = useNavigate();
  const [reports, setReports] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchReports = async () => {
      try {
        const res = await getReportHistory();
        setReports(res.data.reports || []);
      } catch {
        // silent
      } finally {
        setLoading(false);
      }
    };
    fetchReports();
  }, []);

  return (
    <div className="max-w-4xl mx-auto animate-fade-in">
      <div className="flex items-end justify-between mb-8">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-slate-900">Your Reports</h2>
          <p className="text-sm text-slate-500 mt-1">{reports.length} report{reports.length === 1 ? '' : 's'} saved</p>
        </div>
        <Button variant="primary" size="sm" icon={Plus} onClick={() => navigate('/analyze')}>New Report</Button>
      </div>

      {loading ? (
        <div className="space-y-3">
          {[0, 1, 2, 3].map((i) => <div key={i} className="skeleton h-20 w-full rounded-2xl" />)}
        </div>
      ) : reports.length === 0 ? (
        <div className="text-center py-16">
          <div className="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center mx-auto mb-4">
            <FileText className="w-5 h-5 text-slate-400" />
          </div>
          <p className="text-sm text-slate-600 mb-5">No reports yet. Start your first analysis.</p>
          <Button variant="primary" icon={Plus} onClick={() => navigate('/analyze')}>Run Analysis</Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {reports.map((report) => (
            <GlassCard
              key={report._id}
              className="p-5 card-hover cursor-pointer group"
              onClick={() => navigate(`/report/${report._id}`)}
            >
              <div className="flex items-start justify-between mb-3">
                <div className="w-9 h-9 rounded-lg bg-slate-100 flex items-center justify-center">
                  <FileText className="w-4 h-4 text-slate-700" />
                </div>
                <span className={`text-base font-bold ${
                  (report.matchScore || 0) >= 70 ? 'text-emerald-600' :
                  (report.matchScore || 0) >= 50 ? 'text-amber-600' : 'text-red-600'
                }`}>
                  {report.matchScore}%
                </span>
              </div>
              <p className="text-sm font-semibold text-slate-900 mb-1.5 line-clamp-2">
                {report.jobDescription?.substring(0, 100) || 'Untitled Report'}
              </p>
              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-500">{new Date(report.generatedAt).toLocaleDateString()}</span>
                <span className="text-xs text-blue-600 font-semibold group-hover:underline underline-offset-4 inline-flex items-center gap-0.5">
                  View <ArrowRight className="w-3 h-3" />
                </span>
              </div>
            </GlassCard>
          ))}
        </div>
      )}
    </div>
  );
};

export default ReportsList;
