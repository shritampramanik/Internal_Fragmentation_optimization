import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { User, Mail, Save, ArrowLeft } from 'lucide-react';
import GlassCard from '../components/GlassCard';
import Button from '../components/Button';
import { useAuth } from '../context/AuthContext';
import { updateProfile } from '../services/api';

const ProfileView = () => {
  const { user, login: setUser } = useAuth();
  const navigate = useNavigate();
  const [name, setName] = useState(user?.name || '');
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  const handleSave = async (e) => {
    e.preventDefault();
    setError('');
    setMessage('');
    if (!name.trim()) {
      setError('Name is required');
      return;
    }
    setSaving(true);
    try {
      const res = await updateProfile({ name: name.trim() });
      setUser(res.data.user);
      setMessage('Profile updated');
    } catch (err) {
      setError(err.message || 'Failed to update profile');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto animate-fade-in">
      <div className="flex items-center gap-3 mb-8">
        <button onClick={() => navigate('/dashboard')} className="text-slate-500 hover:text-slate-900 transition-colors">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-slate-900">Profile Settings</h2>
          <p className="text-sm text-slate-500 mt-0.5">Manage your account information</p>
        </div>
      </div>

      <GlassCard className="p-8">
        <div className="flex items-center gap-4 mb-8 pb-8 border-b border-slate-200">
          <div className="w-14 h-14 rounded-full bg-slate-900 flex items-center justify-center text-white text-xl font-bold">
            {user?.name?.charAt(0)?.toUpperCase() || 'U'}
          </div>
          <div>
            <h3 className="text-lg font-bold text-slate-900">{user?.name}</h3>
            <p className="text-sm text-slate-500 flex items-center gap-1.5 mt-0.5">
              <Mail className="w-3.5 h-3.5" /> {user?.email}
            </p>
          </div>
        </div>

        {error && (
          <div className="mb-6 p-3.5 rounded-xl bg-red-50 border border-red-200 text-red-700 text-sm">{error}</div>
        )}
        {message && (
          <div className="mb-6 p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-700 text-sm">{message}</div>
        )}

        <form onSubmit={handleSave} className="space-y-6">
          <div>
            <label className="label-base">
              <User className="w-3.5 h-3.5 inline mr-1.5 -mt-0.5" />
              Full Name
            </label>
            <input
              type="text"
              className="input-base"
              placeholder="Your full name"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>

          <div>
            <label className="label-base">
              <Mail className="w-3.5 h-3.5 inline mr-1.5 -mt-0.5" />
              Email
            </label>
            <input
              type="email"
              className="input-base"
              value={user?.email || ''}
              disabled
            />
            <p className="text-xs text-slate-500 mt-1.5">Email cannot be changed</p>
          </div>

          <div className="flex items-center gap-3 pt-3">
            <Button type="submit" variant="primary" icon={Save} disabled={saving}>
              {saving ? 'Saving…' : 'Save Changes'}
            </Button>
            <Button variant="secondary" onClick={() => navigate('/dashboard')}>Back to Dashboard</Button>
          </div>
        </form>
      </GlassCard>
    </div>
  );
};

export default ProfileView;
