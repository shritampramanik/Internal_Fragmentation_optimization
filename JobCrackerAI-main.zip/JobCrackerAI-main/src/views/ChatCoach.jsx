import { useState, useRef, useEffect } from 'react';
import { BrainCircuit } from 'lucide-react';
import GlassCard from '../components/GlassCard';
import { chatWithCoach } from '../services/groq';

const ChatCoach = () => {
  const [messages, setMessages] = useState([
    { role: 'assistant', content: 'Hi, I am your AI career coach. Ask me anything about interviews, offers, or career growth.' },
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const messagesEndRef = useRef(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async () => {
    const trimmed = input.trim();
    if (!trimmed || isLoading) return;
    const userMessage = { role: 'user', content: trimmed };
    const updatedMessages = [...messages, userMessage];
    setMessages(updatedMessages);
    setInput('');
    setIsLoading(true);
    setError('');
    try {
      const reply = await chatWithCoach(updatedMessages);
      setMessages([...updatedMessages, { role: 'assistant', content: reply }]);
    } catch (err) {
      setError(err.message || 'Something went wrong.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <GlassCard className="flex flex-col h-[calc(100vh-130px)] p-0 overflow-hidden">
      <div className="px-5 h-14 border-b border-slate-200 flex items-center gap-3 bg-white shrink-0">
        <div className="w-8 h-8 rounded-full bg-slate-900 flex items-center justify-center">
          <BrainCircuit className="w-4 h-4 text-white" />
        </div>
        <div className="min-w-0">
          <h3 className="text-sm font-semibold text-slate-900 truncate">Career Coach</h3>
          <p className="text-xs text-slate-500 truncate">Powered by Groq</p>
        </div>
      </div>

      <div className="flex-1 px-5 py-6 overflow-y-auto space-y-5 custom-scrollbar bg-white">
        {messages.map((msg, i) => (
          <div
            key={i}
            className={`flex gap-3 max-w-[75%] ${msg.role === 'user' ? 'ml-auto justify-end' : ''}`}
          >
            {msg.role === 'assistant' && (
              <div className="w-8 h-8 rounded-full bg-slate-100 flex-shrink-0 flex items-center justify-center">
                <BrainCircuit className="w-4 h-4 text-slate-700" />
              </div>
            )}
            <div
              className={`rounded-2xl px-4 py-3 text-sm leading-relaxed whitespace-pre-wrap ${
                msg.role === 'user'
                  ? 'bg-slate-900 text-white rounded-tr-none'
                  : 'bg-slate-50 border border-slate-200 text-slate-700 rounded-tl-none'
              }`}
            >
              {msg.content}
            </div>
          </div>
        ))}

        {isLoading && (
          <div className="flex gap-3 max-w-[75%]">
            <div className="w-8 h-8 rounded-full bg-slate-100 flex-shrink-0 flex items-center justify-center">
              <BrainCircuit className="w-4 h-4 text-slate-700" />
            </div>
            <div className="rounded-2xl rounded-tl-none px-4 py-3 bg-slate-50 border border-slate-200">
              <div className="flex gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-slate-400 animate-bounce" />
                <span className="w-1.5 h-1.5 rounded-full bg-slate-400 animate-bounce" style={{ animationDelay: '0.15s' }} />
                <span className="w-1.5 h-1.5 rounded-full bg-slate-400 animate-bounce" style={{ animationDelay: '0.3s' }} />
              </div>
            </div>
          </div>
        )}

        {error && (
          <div className="flex justify-center">
            <div className="bg-red-50 border border-red-200 text-red-700 text-sm px-4 py-2.5 rounded-xl">{error}</div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      <div className="px-5 py-4 border-t border-slate-200 bg-white">
        <div className="relative">
          <input
            type="text"
            placeholder="Ask me anything…"
            className="input-base pr-12"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            disabled={isLoading}
          />
          <button
            className="absolute right-1.5 top-1/2 -translate-y-1/2 w-8 h-8 rounded-lg bg-slate-900 flex items-center justify-center text-white hover:bg-slate-800 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            onClick={handleSend}
            disabled={isLoading || !input.trim()}
          >
            <svg viewBox="0 0 24 24" className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M12 19V5M5 12l7-7 7 7" />
            </svg>
          </button>
        </div>
      </div>
    </GlassCard>
  );
};

export default ChatCoach;
