import { useState } from 'react';
import { Outlet, useNavigate, useLocation } from 'react-router-dom';
import {
  LineChart,
  FileText,
  User,
  LogOut,
  BrainCircuit,
  Zap,
  PanelLeftClose,
  PanelLeftOpen,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

const navigation = [
  { id: '/dashboard', icon: LineChart, label: 'Dashboard', href: '/dashboard' },
  { id: '/analyze', icon: Zap, label: 'Analyzer', href: '/analyze' },
  { id: '/reports', icon: FileText, label: 'Reports', href: '/reports' },
];

const bottomItems = [
  { id: '/profile', icon: User, label: 'Settings', href: '/profile' },
];

const AppShell = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [isCollapsed, setIsCollapsed] = useState(false);

  const initials = user?.name
    ? user.name.split(' ').map((p) => p[0]).slice(0, 2).join('').toUpperCase()
    : 'JD';

  return (
    <div className="min-h-screen flex bg-white text-slate-900 antialiased">
      <aside
        className={[
          'sticky top-0 h-screen border-r border-slate-200 bg-white flex flex-col justify-between transition-all duration-200 z-30',
          isCollapsed ? 'w-[64px]' : 'w-[240px]',
        ].join(' ')}
      >
        <div className="flex flex-col">
          <div
            onClick={() => navigate('/dashboard')}
            className="flex items-center gap-2.5 h-14 px-4 cursor-pointer select-none border-b border-slate-100 hover:bg-slate-50 transition-colors"
          >
            <div className="w-7 h-7 rounded-lg bg-slate-900 flex items-center justify-center flex-shrink-0">
              <BrainCircuit className="w-3.5 h-4 text-white" />
            </div>
            {!isCollapsed && (
              <span className="text-sm font-bold tracking-tight text-slate-900">
                JobCracker<span className="text-blue-600 font-semibold">.ai</span>
              </span>
            )}
          </div>

          <nav className="mt-2 px-2 space-y-0.5">
            {navigation.map((item) => {
              const active =
                location.pathname === item.href ||
                (item.href !== '/dashboard' && location.pathname.startsWith(item.href));
              return (
                <button
                  key={item.id}
                  onClick={() => navigate(item.href)}
                  className={[
                    'w-full flex items-center gap-3 px-3 h-9 rounded-lg text-[13px] font-medium transition-colors',
                    active ? 'bg-slate-100 text-slate-900' : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900',
                  ].join(' ')}
                >
                  <item.icon className="w-4 h-4 flex-shrink-0" />
                  {!isCollapsed && <span>{item.label}</span>}
                </button>
              );
            })}
          </nav>
        </div>

        <div className="px-2 space-y-0.5">
          {bottomItems.map((item) => (
            <button
              key={item.id}
              onClick={() => navigate(item.href)}
              className={[
                'w-full flex items-center gap-3 px-3 h-9 rounded-lg text-[13px] font-medium transition-colors',
                location.pathname === item.href
                  ? 'bg-slate-100 text-slate-900'
                  : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900',
              ].join(' ')}
            >
              <item.icon className="w-4 h-4 flex-shrink-0" />
              {!isCollapsed && <span>{item.label}</span>}
            </button>
          ))}

          <button
            onClick={() => setIsCollapsed(!isCollapsed)}
            className="flex items-center gap-3 px-3 h-9 rounded-lg text-[13px] font-medium text-slate-600 hover:bg-slate-50 hover:text-slate-900 transition-colors w-full mt-1"
          >
            {isCollapsed ? (
              <PanelLeftOpen className="w-4 h-4 mx-auto" />
            ) : (
              <>
                <PanelLeftClose className="w-4 h-4 flex-shrink-0" />
                <span>Collapse</span>
              </>
            )}
          </button>

          <div className="border-t border-slate-100 my-2" />

          {!isCollapsed && (
            <div className="px-3 py-2 flex items-center gap-2.5">
              <div className="w-7 h-7 rounded-full bg-slate-900 text-white flex items-center justify-center text-[11px] font-bold flex-shrink-0">
                {initials}
              </div>
              <div className="min-w-0 flex-1">
                <p className="text-[13px] font-semibold text-slate-900 truncate">{user?.name}</p>
                <p className="text-xs text-slate-500 truncate">Free Plan</p>
              </div>
            </div>
          )}

          <button
            onClick={() => {
              logout();
              navigate('/');
            }}
            className="flex items-center gap-3 px-3 h-9 rounded-lg text-[13px] font-medium text-slate-600 hover:text-red-600 hover:bg-red-50 transition-colors w-full"
          >
            <LogOut className="w-4 h-4 flex-shrink-0" />
            {!isCollapsed && <span>Sign Out</span>}
          </button>
        </div>
      </aside>

      <main className="flex-1 overflow-y-auto">
        <div className="max-w-5xl mx-auto px-6 sm:px-10 py-10">
          <Outlet />
        </div>
      </main>
    </div>
  );
};

export default AppShell;
