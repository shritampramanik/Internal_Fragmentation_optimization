import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { FileText, Target, BrainCircuit, ArrowLeft, Zap } from 'lucide-react';
import Button from '../components/Button';
import GlassCard from '../components/GlassCard';
import { getReport } from '../services/api';

const ReportView = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [report, setReport] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchReport = async () => {
      try {
        const res = await getReport(id);
        setReport(res.data.report);
      } catch (err) {
        setError(err.message || 'Failed to load report');
      } finally {
        setLoading(false);
      }
    };
    fetchReport();
  }, [id]);

  const getScoreColor = (score) => {
    if (score >= 80) return 'from-emerald-500 to-teal-500';
    if (score >= 60) return 'from-amber-400 to-orange-500';
    return 'from-red-400 to-rose-500';
  };

  const getScoreLabel = (score) => {
    if (score >= 80) return 'Strong Match';
    if (score >= 60) return 'Good Match';
    if (score >= 40) return 'Fair Match';
    return 'Needs Work';
  };

  const getScoreLabelColor = (score) => {
    if (score >= 80) return 'badge-success';
    if (score >= 60) return 'badge-warning';
    return 'badge-danger';
  };

  const getSkillBarColor = (match) => {
    if (match > 80) return 'bg-emerald-500';
    if (match > 50) return 'bg-amber-500';
    return 'bg-red-500';
  };

  const recommendationIcons = { 'Resume Edit': FileText, 'Study Plan': BrainCircuit, 'Interview Prep': Target };
  const recommendationColors = { 'Resume Edit': 'text-amber-600', 'Study Plan': 'text-slate-700', 'Interview Prep': 'text-emerald-600' };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="text-sm text-slate-500 animate-fade-in">Loading report…</div>
      </div>
    );
  }

  if (error || !report) {
    return (
      <div className="text-center py-20">
        <p className="text-sm text-red-600 mb-4">{error || 'Report not found'}</p>
        <Button variant="secondary" onClick={() => navigate('/dashboard')}>Back to Dashboard</Button>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto py-8 animate-fade-in space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <button onClick={() => navigate('/dashboard')} className="text-slate-500 hover:text-slate-900 transition-colors">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h2 className="text-2xl font-bold tracking-tight text-slate-900">Report Details</h2>
            <p className="text-xs text-slate-500 mt-1 truncate max-w-md">{report.jobDescription?.substring(0, 80)}…</p>
          </div>
        </div>
        <Button variant="secondary" icon={Zap} onClick={() => navigate('/analyze')}>New Analysis</Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        <GlassCard className="p-8 flex flex-col items-center justify-center text-center relative overflow-hidden card-hover">
          <div className="absolute -bottom-4 -right-4 opacity-[0.06]">
            <Target className="w-40 h-40 text-slate-900" />
          </div>
          <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Match Score</p>
          <div className={`text-6xl font-extrabold bg-gradient-to-br ${getScoreColor(report.matchScore)} bg-clip-text text-transparent mb-2`}>
            {report.matchScore}<span className="text-3xl">%</span>
          </div>
          <span className={`badge ${getScoreLabelColor(report.matchScore)}`}>{getScoreLabel(report.matchScore)}</span>
        </GlassCard>

        <GlassCard className="p-8 flex flex-col items-center justify-center text-center card-hover">
          <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">ATS Score</p>
          <div className={`text-6xl font-extrabold bg-gradient-to-br ${getScoreColor(report.atsScore)} bg-clip-text text-transparent mb-2`}>
            {report.atsScore}<span className="text-3xl">%</span>
          </div>
          <span className={`badge ${getScoreLabelColor(report.atsScore)}`}>{getScoreLabel(report.atsScore)}</span>
        </GlassCard>
      </div>

      <p className="text-center text-xs text-slate-500">Generated on {new Date(report.generatedAt).toLocaleString()}</p>

      <GlassCard className="p-6">
        <h3 className="text-sm font-semibold text-slate-900 mb-5">Skill Analysis</h3>
        <div className="space-y-3">
          {(report.missingSkills || []).map((skill, i) => (
            <div key={i}>
              <div className="flex justify-between text-sm mb-1.5">
                <span className="font-medium text-slate-700">{skill.skill}</span>
                <span className="text-slate-500">{skill.match}%</span>
              </div>
              <div className="w-full bg-slate-100 rounded-full h-2">
                <div className={`h-2 rounded-full ${getSkillBarColor(skill.match)}`} style={{ width: `${skill.match}%`, transition: 'width 0.8s ease-out' }} />
              </div>
            </div>
          ))}
        </div>
      </GlassCard>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        <GlassCard className="p-6">
          <h3 className="text-sm font-semibold text-emerald-700 mb-4">Strengths</h3>
          <ul className="space-y-2.5">
            {(report.strengths || []).map((s, i) => (
              <li key={i} className="flex items-start gap-2.5 text-sm text-slate-600"><span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-1.5 flex-shrink-0" />{s}</li>
            ))}
          </ul>
        </GlassCard>
        <GlassCard className="p-6">
          <h3 className="text-sm font-semibold text-red-700 mb-4">Areas to Improve</h3>
          <ul className="space-y-2.5">
            {(report.weaknesses || []).map((w, i) => (
              <li key={i} className="flex items-start gap-2.5 text-sm text-slate-600"><span className="w-1.5 h-1.5 rounded-full bg-red-500 mt-1.5 flex-shrink-0" />{w}</li>
            ))}
          </ul>
        </GlassCard>
      </div>

      <GlassCard className="p-6">
        <h3 className="text-sm font-semibold text-slate-900 mb-5">Preparation Plan</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {(report.preparationPlan || []).map((action, i) => {
            const Icon = recommendationIcons[action.type] || Target;
            const color = recommendationColors[action.type] || 'text-slate-700';
            return (
              <div key={i} className="flex items-start gap-3.5 p-4 rounded-xl border border-slate-200">
                <div className={`p-2 rounded-lg bg-slate-100 ${color}`}><Icon className="w-4 h-4" /></div>
                <div>
                  <h4 className="text-sm font-semibold text-slate-900">{action.title}</h4>
                  <p className="text-xs text-slate-500 mt-0.5">{action.type}</p>
                </div>
              </div>
            );
          })}
        </div>
      </GlassCard>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        <GlassCard className="p-6">
          <h3 className="text-sm font-semibold text-slate-900 mb-4">Technical Questions</h3>
          <ol className="space-y-2.5 list-decimal list-inside text-sm text-slate-600">
            {(report.technicalQuestions || []).map((q, i) => <li key={i} className="pl-1">{q}</li>)}
          </ol>
        </GlassCard>
        <GlassCard className="p-6">
          <h3 className="text-sm font-semibold text-slate-900 mb-4">Behavioral Questions</h3>
          <ol className="space-y-2.5 list-decimal list-inside text-sm text-slate-600">
            {(report.behavioralQuestions || []).map((q, i) => <li key={i} className="pl-1">{q}</li>)}
          </ol>
        </GlassCard>
      </div>
    </div>
  );
};

export default ReportView;
