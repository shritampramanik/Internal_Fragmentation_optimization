import { useState } from 'react';
import { BrainCircuit, ArrowRight, CheckCircle2, Star } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import Button from '../components/Button';

const features = [
  { icon: BrainCircuit, title: 'ATS Optimization', desc: 'Beat modern applicant tracking systems with AI-driven keyword matching and formatting insights.' },
  { icon: ArrowRight, title: 'Skill Gap Detection', desc: 'Identify exactly which skills to develop before applying, with a structured learning path.' },
  { icon: CheckCircle2, title: 'Interview Prep', desc: 'Mock questions tailored to the specific role, company, and seniority level.' },
];

const testimonials = [
  { name: 'Sarah Chen', role: 'Senior Engineer at Vercel', body: 'Cut my application-to-interview rate by 3x. The ATS insights alone are worth it.', initials: 'SC' },
  { name: 'Marcus Johnson', role: 'Product Designer at Linear', body: 'Finally a tool that actually understands modern job descriptions. Clean, fast, precise.', initials: 'MJ' },
  { name: 'Aisha Patel', role: 'Engineering Manager at Stripe', body: 'Use it for all my roles. The preparation roadmap makes interview prep feel systematic.', initials: 'AP' },
];

const XIcon = (props) => (
  <svg viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
  </svg>
);

const LinkedInIcon = (props) => (
  <svg viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 0 1-2.063-2.065 2.064 2.064 0 1 1 2.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
  </svg>
);

const GitHubIcon = (props) => (
  <svg viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path d="M12 .5A12 12 0 0 0 8.2 23.9c.6.1.8-.3.8-.6v-2.2c-3.3.7-4-1.4-4-1.4-.6-1.4-1.3-1.8-1.3-1.8-1.1-.7.1-.7.1-.7 1.2.1 1.8 1.2 1.8 1.2 1.1 1.8 2.8 1.3 3.5 1 .1-.8.4-1.3.7-1.6-2.7-.3-5.5-1.3-5.5-6A4.7 4.7 0 0 1 6.4 8.6a4.4 4.4 0 0 1 .1-3.1s1-.3 3.3 1.2a11.5 11.5 0 0 1 6 0c2.3-1.5 3.3-1.2 3.3-1.2.5 1 .5 2.2.1 3.1a4.7 4.7 0 0 1 1.3 3.3c0 4.7-2.8 5.7-5.5 6 .4.3.8 1 .8 2v3c0 .3.2.7.8.6A12 12 0 0 0 12 .5z"/>
  </svg>
);

const LandingPage = () => {
  const [showOptions, setShowOptions] = useState(false);
  const navigate = useNavigate();

  return (
    <div className="relative min-h-screen flex flex-col">
      <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-slate-200/60">
        <div className="max-w-6xl mx-auto px-6 h-14 flex items-center justify-between">
          <div className="flex items-center gap-2.5 cursor-pointer select-none" onClick={() => navigate('/')}>
            <div className="w-8 h-8 rounded-lg bg-slate-950 flex items-center justify-center">
              <BrainCircuit className="w-4 h-5 text-white" />
            </div>
            <span className="text-lg font-bold tracking-tight text-slate-900">JobCracker<span className="text-blue-600 font-semibold">.ai</span></span>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" onClick={() => navigate('/login')}>Log In</Button>
            <Button variant="primary" size="sm" onClick={() => navigate('/register')}>Sign Up</Button>
          </div>
        </div>
      </nav>

      <section className="relative pt-24 pb-20 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-slate-50/60 to-white pointer-events-none" />
        <div className="max-w-6xl mx-auto px-6 relative">
          <div className="flex flex-col items-center text-center max-w-3xl mx-auto">
            <div className="inline-flex items-center gap-2 bg-white border border-slate-200 rounded-full px-3 py-1.5 mb-8 animate-fade-in-up shadow-sm">
              <span className="flex items-center gap-1.5 bg-slate-950 text-white text-xs font-semibold px-2 py-0.5 rounded-full">New</span>
              <span className="text-xs font-medium text-slate-600">AI-powered resume analysis is live</span>
            </div>

            <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold tracking-tight text-slate-900 mb-6 animate-fade-in-up leading-[1.1]" style={{ animationDelay: '0.05s' }}>
              Analyze your resume.<br />Land the role.
            </h1>

            <p className="text-lg text-slate-500 max-w-xl mb-10 animate-fade-in-up leading-relaxed" style={{ animationDelay: '0.1s' }}>
              Upload your resume and get an instant ATS match score, skill gap breakdown, and a structured preparation plan.
            </p>

            <div className="flex flex-col sm:flex-row gap-3 w-full sm:w-auto animate-fade-in-up" style={{ animationDelay: '0.15s' }}>
              <Button variant="primary" size="lg" icon={ArrowRight} onClick={() => setShowOptions(true)}>Get Started Free</Button>
              <Button variant="secondary" size="lg">View How It Works</Button>
            </div>

            <p className="text-xs text-slate-400 mt-4 animate-fade-in-up" style={{ animationDelay: '0.2s' }}>
              No credit card required · Analysis takes ~15 seconds
            </p>
          </div>
        </div>
      </section>

      {showOptions && (
        <section className="pb-24">
          <div className="max-w-2xl mx-auto px-6">
            <div className="card-elevated p-8 animate-scale-in">
              <h2 className="text-2xl font-bold text-slate-900 mb-2">Choose your path</h2>
              <p className="text-sm text-slate-500 mb-6">Try instantly with no account, or sign up to save reports and track progress.</p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
                <button onClick={() => navigate('/analyze')} className="card-hover p-6 text-left rounded-2xl">
                  <div className="w-10 h-10 rounded-xl bg-blue-50 flex items-center justify-center mb-3">
                    <ArrowRight className="w-5 h-5 text-blue-600" />
                  </div>
                  <h3 className="text-sm font-semibold text-slate-900 mb-1">Continue as Guest</h3>
                  <p className="text-xs text-slate-500 leading-relaxed">Analyze instantly without creating an account.</p>
                </button>
                <button onClick={() => navigate('/login')} className="card-hover p-6 text-left rounded-2xl">
                  <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center mb-3">
                    <BrainCircuit className="w-5 h-5 text-slate-900" />
                  </div>
                  <h3 className="text-sm font-semibold text-slate-900 mb-1">Create Account</h3>
                  <p className="text-xs text-slate-500 leading-relaxed">Save reports and access your personal dashboard.</p>
                </button>
              </div>
              <Button variant="ghost" onClick={() => setShowOptions(false)}>Back</Button>
            </div>
          </div>
        </section>
      )}

      <section className="py-20 bg-white">
        <div className="max-w-6xl mx-auto px-6">
          <div className="text-center mb-14">
            <h2 className="text-3xl font-bold tracking-tight text-slate-900 mb-3">Everything you need to prepare</h2>
            <p className="text-slate-500 max-w-lg mx-auto">From ATS scoring to interview questions, built for professionals who take their career seriously.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {features.map((feat) => (
              <div key={feat.title} className="card-hover p-6 rounded-2xl">
                <feat.icon className="w-5 h-5 text-blue-600 mb-4" />
                <h3 className="text-base font-semibold text-slate-900 mb-2">{feat.title}</h3>
                <p className="text-sm text-slate-500 leading-relaxed">{feat.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-slate-50/60">
        <div className="max-w-6xl mx-auto px-6">
          <h2 className="text-3xl font-bold tracking-tight text-center text-slate-900 mb-3">Trusted by engineers at leading companies</h2>
          <p className="text-sm text-slate-500 text-center mb-14">Join thousands using JobCracker to accelerate their job search.</p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {testimonials.map((t) => (
              <div key={t.name} className="card p-6 rounded-2xl card-hover">
                <div className="flex items-center gap-1 mb-3">
                  {[...Array(5)].map((_, i) => <Star key={i} className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />)}
                </div>
                <p className="text-sm text-slate-600 leading-relaxed mb-4">"{t.body}"</p>
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center text-xs font-bold text-slate-700">{t.initials}</div>
                  <div>
                    <p className="text-sm font-semibold text-slate-900">{t.name}</p>
                    <p className="text-xs text-slate-500">{t.role}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-3xl mx-auto px-6 text-center">
          <h2 className="text-3xl font-bold tracking-tight text-slate-900 mb-3">Ready to improve your resume?</h2>
          <p className="text-slate-500 mb-8">Start your free analysis in under a minute. No signup required for the first run.</p>
          <Button variant="primary" size="lg" icon={ArrowRight} onClick={() => setShowOptions(true)}>Start Free Analysis</Button>
        </div>
      </section>

      <footer className="border-t border-slate-200/60 bg-white py-12">
        <div className="max-w-6xl mx-auto px-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-2.5">
              <div className="w-7 h-7 rounded-md bg-slate-950 flex items-center justify-center">
                <BrainCircuit className="w-3.5 h-4 text-white" />
              </div>
              <span className="text-sm font-bold text-slate-900">JobCracker<span className="text-blue-600 font-semibold">.ai</span></span>
            </div>
            <div className="flex items-center gap-6">
              <span className="text-sm text-slate-500">© {new Date().getFullYear()}</span>
              <div className="flex items-center gap-4">
                {[XIcon, LinkedInIcon, GitHubIcon].map((Icon, i) => (
                  <button key={i} className="text-slate-400 hover:text-slate-600 transition-colors"><Icon className="w-4 h-4" /></button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default LandingPage;
