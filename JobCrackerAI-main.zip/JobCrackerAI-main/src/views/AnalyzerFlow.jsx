import { useState, useRef } from 'react';
import { FileText, Upload, Zap, BrainCircuit, ArrowRight } from 'lucide-react';
import Button from '../components/Button';
import { guestAnalyze, uploadResume, generateReport } from '../services/api';
import { useAuth } from '../context/AuthContext';

const steps = [
  { label: 'Upload', done: true },
  { label: 'Analyze', done: false },
  { label: 'Results', done: false },
];

const AnalyzerFlow = () => {
  const { user } = useAuth();
  const [step, setStep] = useState(0);
  const [resumeFile, setResumeFile] = useState(null);
  const [jobDescription, setJobDescription] = useState('');
  const [error, setError] = useState('');
  const [analysisResult, setAnalysisResult] = useState(null);
  const fileInputRef = useRef(null);

  const currentSteps = steps.map((s, i) => ({ ...s, done: i < step }));

  const handleFileChange = (e) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.type !== 'application/pdf') {
        setError('Only PDF files are accepted');
        return;
      }
      if (file.size > 5 * 1024 * 1024) {
        setError('File size must be under 5MB');
        return;
      }
      setResumeFile(file);
      setError('');
    }
  };

  const handleAnalyze = async () => {
    if (!resumeFile) {
      setError('Upload your resume to continue');
      return;
    }
    if (!jobDescription.trim()) {
      setError('Paste the job description to continue');
      return;
    }
    setError('');
    setStep(1);

    try {
      let report;
      if (user) {
        const uploadForm = new FormData();
        uploadForm.append('resume', resumeFile);
        const uploadRes = await uploadResume(uploadForm);
        const genRes = await generateReport(uploadRes.data.resume._id, jobDescription.trim());
        report = genRes.data.report;
      } else {
        const formData = new FormData();
        formData.append('resume', resumeFile);
        formData.append('jobDescription', jobDescription.trim());
        const res = await guestAnalyze(formData);
        report = res.data.report;
      }
      setAnalysisResult(report);
      setStep(2);
    } catch (err) {
      setError(err.message || 'Analysis failed. Please try again.');
      setStep(0);
    }
  };

  const getScoreColor = (score) => {
    if (score >= 80) return 'text-emerald-600';
    if (score >= 60) return 'text-amber-600';
    return 'text-red-600';
  };

  const getSkillBarColor = (match) => {
    if (match > 80) return 'bg-emerald-500';
    if (match > 50) return 'bg-amber-500';
    return 'bg-red-500';
  };

  const recColors = { 'Resume Edit': 'bg-slate-100 text-slate-700', 'Study Plan': 'bg-blue-50 text-blue-700', 'Interview Prep': 'bg-emerald-50 text-emerald-700' };
  const recIcons = { 'Resume Edit': FileText, 'Study Plan': BrainCircuit, 'Interview Prep': ArrowRight };

  return (
    <div className="max-w-3xl mx-auto py-10">
      {!user && step === 0 && (
        <div className="mb-6 p-4 rounded-xl bg-blue-50 border border-blue-200 text-sm text-blue-700">
          Guest Mode · Analysis is not saved. <a href="/login" className="font-semibold underline underline-offset-4">Sign up</a> to save reports.
        </div>
      )}

      {/* Stepper */}
      <div className="flex items-center gap-3 mb-10">
        {currentSteps.map((s, i) => (
          <div key={i} className="flex items-center gap-3">
            <div className={`h-7 px-2.5 rounded-full text-xs font-semibold flex items-center ${s.done ? 'bg-slate-950 text-white' : 'bg-slate-100 text-slate-500'}`}>
              {s.label}
            </div>
            {i < currentSteps.length - 1 && <div className={`h-px w-8 ${s.done ? 'bg-slate-950' : 'bg-slate-200'}`} />}
          </div>
        ))}
      </div>

      {error && (
        <div className="mb-6 p-4 rounded-xl bg-red-50 border border-red-200 text-red-700 text-sm">{error}</div>
      )}

      {step === 0 && (
        <div className="animate-fade-in space-y-6">
          <div className="text-center mb-2">
            <h2 className="text-2xl font-bold tracking-tight text-slate-900">Analyze your resume</h2>
            <p className="text-sm text-slate-500 mt-2 max-w-md mx-auto">Upload your resume PDF and paste a job description to receive a comprehensive ATS analysis.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            <button
              onClick={() => fileInputRef.current?.click()}
              className="card-hover w-full text-left p-8 rounded-2xl border-2 border-dashed border-slate-200"
            >
              <input ref={fileInputRef} type="file" accept=".pdf" className="hidden" onChange={handleFileChange} />
              {resumeFile ? (
                <div>
                  <div className="w-12 h-12 rounded-xl bg-emerald-50 flex items-center justify-center mb-4">
                    <FileText className="w-6 h-6 text-emerald-600" />
                  </div>
                  <p className="text-sm font-semibold text-slate-900 mb-1">{resumeFile.name}</p>
                  <p className="text-xs text-slate-500">{(resumeFile.size / 1024).toFixed(1)} KB • PDF</p>
                  <button
                    className="text-xs text-blue-600 font-semibold mt-3 underline underline-offset-4"
                    onClick={(e) => { e.stopPropagation(); setResumeFile(null); }}
                  >
                    Remove
                  </button>
                </div>
              ) : (
                <div>
                  <div className="w-12 h-12 rounded-xl bg-slate-100 flex items-center justify-center mb-4">
                    <Upload className="w-6 h-6 text-slate-700" />
                  </div>
                  <p className="text-sm font-semibold text-slate-900 mb-1">Upload Resume</p>
                  <p className="text-xs text-slate-500">Click to browse · PDF · Max 5MB</p>
                </div>
              )}
            </button>

            <div className="card-elevated p-6 rounded-2xl flex flex-col">
              <label className="label-base mb-3">Job Description</label>
              <textarea
                className="flex-1 input-base text-sm resize-none leading-relaxed"
                style={{ minHeight: '160px' }}
                placeholder="Paste the job description here…"
                value={jobDescription}
                onChange={(e) => setJobDescription(e.target.value)}
              />
            </div>
          </div>

          <div className="text-center pt-2">
            <Button variant="primary" size="lg" onClick={handleAnalyze} icon={Zap}>Analyze Match</Button>
          </div>
        </div>
      )}

      {step === 1 && (
        <div className="animate-fade-in flex flex-col items-center justify-center py-24">
          <div className="relative w-16 h-16 mb-8">
            <div className="absolute inset-0 rounded-full border-4 border-slate-200"></div>
            <div className="absolute inset-0 rounded-full border-4 border-slate-950 border-t-transparent" style={{ animation: 'spin 1s linear infinite' }}></div>
            <div className="absolute inset-0 flex items-center justify-center">
              <BrainCircuit className="w-6 h-6 text-slate-950" />
            </div>
          </div>
          <h3 className="text-lg font-semibold text-slate-900 mb-2">Analyzing your resume…</h3>
          <div className="space-y-1 text-sm text-slate-500">
            <p>Parsing resume structure</p>
            <p>Extracting key skills and experience</p>
            <p>Running ATS match algorithm</p>
            <p>Preparing results</p>
          </div>
        </div>
      )}

      {step === 2 && analysisResult && (
        <div className="animate-fade-in space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold tracking-tight text-slate-900">Analysis complete</h2>
              <p className="text-sm text-slate-500 mt-1">ATS match results generated</p>
            </div>
            <Button variant="secondary" onClick={() => { setStep(0); setAnalysisResult(null); setResumeFile(null); }}>New Analysis</Button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="card-elevated p-6 rounded-2xl flex flex-col items-center text-center">
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Match Score</p>
              <p className={`text-5xl font-bold ${getScoreColor(analysisResult.matchScore)}`}>{analysisResult.matchScore}%</p>
              <span className={`mt-2 badge ${analysisResult.matchScore >= 70 ? 'badge-success' : analysisResult.matchScore >= 50 ? 'badge-warning' : 'badge-danger'}`}>{(analysisResult.matchScore || 0) >= 80 ? 'Strong' : (analysisResult.matchScore || 0) >= 60 ? 'Good' : 'Needs Work'}</span>
            </div>
            <div className="card-elevated p-6 rounded-2xl flex flex-col items-center text-center">
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">ATS Score</p>
              <p className={`text-5xl font-bold ${getScoreColor(analysisResult.atsScore)}`}>{analysisResult.atsScore}%</p>
              <span className={`mt-2 badge ${analysisResult.atsScore >= 70 ? 'badge-success' : analysisResult.atsScore >= 50 ? 'badge-warning' : 'badge-danger'}`}>{(analysisResult.atsScore || 0) >= 80 ? 'Strong' : (analysisResult.atsScore || 0) >= 60 ? 'Good' : 'Needs Work'}</span>
            </div>
            <div className="card-elevated p-6 rounded-2xl">
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-4">Key Skills</p>
              <div className="space-y-3">
                {(analysisResult.missingSkills || []).slice(0, 4).map((skill, i) => (
                  <div key={i}>
                    <div className="flex justify-between text-xs mb-1.5">
                      <span className="font-medium text-slate-700">{skill.skill}</span>
                      <span className="text-slate-500">{skill.match}%</span>
                    </div>
                    <div className="w-full bg-slate-100 rounded-full h-1.5">
                      <div className={`h-1.5 rounded-full ${getSkillBarColor(skill.match)}`} style={{ width: `${skill.match}%`, transition: 'width 0.8s ease-out' }} />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            <div className="card-elevated p-6 rounded-2xl">
              <h3 className="text-sm font-semibold text-emerald-700 mb-4">Strengths</h3>
              <ul className="space-y-2.5">
                {(analysisResult.strengths || []).map((s, i) => (
                  <li key={i} className="flex items-start gap-2.5 text-sm text-slate-700"><span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-1.5 flex-shrink-0" />{s}</li>
                ))}
              </ul>
            </div>
            <div className="card-elevated p-6 rounded-2xl">
              <h3 className="text-sm font-semibold text-red-700 mb-4">Areas to Improve</h3>
              <ul className="space-y-2.5">
                {(analysisResult.weaknesses || []).map((w, i) => (
                  <li key={i} className="flex items-start gap-2.5 text-sm text-slate-700"><span className="w-1.5 h-1.5 rounded-full bg-red-500 mt-1.5 flex-shrink-0" />{w}</li>
                ))}
              </ul>
            </div>
          </div>

          <div className="card-elevated p-6 rounded-2xl">
            <h3 className="text-sm font-semibold text-slate-900 mb-4">Preparation Plan</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {(analysisResult.preparationPlan || []).map((action, i) => {
                const I = recIcons[action.type] || ArrowRight;
                const c = recColors[action.type] || 'bg-slate-100 text-slate-700';
                return (
                  <div key={i} className="flex items-start gap-3.5 p-4 rounded-xl border border-slate-200">
                    <span className={`inline-flex items-center justify-center w-8 h-8 rounded-lg ${c}`}><I className="w-4 h-4" /></span>
                    <div>
                      <h4 className="text-sm font-semibold text-slate-900">{action.title}</h4>
                      <p className="text-xs text-slate-500 mt-0.5">{action.type}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            <div className="card-elevated p-6 rounded-2xl">
              <h3 className="text-sm font-semibold text-slate-900 mb-4">Technical Questions</h3>
              <ol className="space-y-2.5 list-decimal list-inside text-sm text-slate-600">
                {(analysisResult.technicalQuestions || []).map((q, i) => <li key={i} className="pl-1">{q}</li>)}
              </ol>
            </div>
            <div className="card-elevated p-6 rounded-2xl">
              <h3 className="text-sm font-semibold text-slate-900 mb-4">Behavioral Questions</h3>
              <ol className="space-y-2.5 list-decimal list-inside text-sm text-slate-600">
                {(analysisResult.behavioralQuestions || []).map((q, i) => <li key={i} className="pl-1">{q}</li>)}
              </ol>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AnalyzerFlow;
