import { Clock, Plus } from 'lucide-react';
import GlassCard from '../components/GlassCard';
import Button from '../components/Button';

const MOCK_JOBS = {
  wishlist: [
    { id: '1', company: 'Stripe', role: 'Frontend Engineer', logo: 'S' },
    { id: '2', company: 'Vercel', role: 'Design Engineer', logo: 'V' },
  ],
  applied: [
    { id: '3', company: 'Apple', role: 'UI Developer', logo: 'A', date: '2d ago' },
    { id: '4', company: 'Linear', role: 'Product Engineer', logo: 'L', date: '1w ago' },
  ],
  interviewing: [
    { id: '5', company: 'OpenAI', role: 'React Specialist', logo: 'O', nextRound: 'Tech Screen' },
  ],
};

const columns = [
  { key: 'wishlist', label: 'Wishlist', dot: 'bg-slate-400' },
  { key: 'applied', label: 'Applied', dot: 'bg-blue-500' },
  { key: 'interviewing', label: 'Interviewing', dot: 'bg-emerald-500' },
];

const TrackerView = () => (
  <div className="h-full flex flex-col">
    <div className="flex items-center justify-between mb-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight text-slate-900">Job Pipeline</h2>
        <p className="text-sm text-slate-500 mt-1">Track and manage your applications.</p>
      </div>
      <Button variant="secondary" size="sm" icon={Plus}>Add Job</Button>
    </div>

    <div className="flex-1 flex gap-5 overflow-x-auto pb-4 custom-scrollbar">
      {columns.map((column) => (
        <div key={column.key} className="w-[300px] flex-shrink-0 flex flex-col gap-2.5">
          <div className="flex items-center justify-between px-1 h-8">
            <div className="flex items-center gap-2">
              <span className={`w-2 h-2 rounded-full ${column.dot}`} />
              <span className="text-[13px] font-semibold text-slate-700 uppercase tracking-wider">{column.label}</span>
            </div>
            <span className="text-xs text-slate-500 font-medium bg-slate-100 px-2 py-0.5 rounded-md">
              {MOCK_JOBS[column.key].length}
            </span>
          </div>
          {MOCK_JOBS[column.key].map((job) => (
            <GlassCard key={job.id} className="p-4 card-hover">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-8 h-8 rounded-lg bg-slate-100 flex items-center justify-center text-slate-900 font-bold text-xs flex-shrink-0">
                  {job.logo}
                </div>
                <div className="min-w-0">
                  <h4 className="text-sm font-semibold text-slate-900 truncate">{job.company}</h4>
                  <p className="text-xs text-slate-500 truncate">{job.role}</p>
                </div>
              </div>
              {job.date && (
                <p className="text-xs text-slate-500 flex items-center gap-1.5 mt-1">
                  <Clock className="w-3 h-3" /> Applied {job.date}
                </p>
              )}
              {job.nextRound && (
                <span className="inline-flex text-xs font-medium text-blue-700 bg-blue-50 px-2.5 py-1 rounded-lg mt-2.5">
                  Next: {job.nextRound}
                </span>
              )}
            </GlassCard>
          ))}
          <button className="w-full h-10 rounded-xl border border-dashed border-slate-200 text-xs font-medium text-slate-500 hover:border-slate-300 hover:text-slate-700 transition-colors">
            + Add
          </button>
        </div>
      ))}
    </div>
  </div>
);

export default TrackerView;
