import { useState, useEffect } from 'react';
import { Target, BrainCircuit, TrendingUp, Zap, FileText } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import GlassCard from '../components/GlassCard';
import Button from '../components/Button';
import { getReportHistory, getResumeHistory } from '../services/api';
import { useAuth } from '../context/AuthContext';

const DashboardHome = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [reports, setReports] = useState([]);
  const [resumes, setResumes] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [reportsRes, resumesRes] = await Promise.all([getReportHistory(), getResumeHistory()]);
        setReports(reportsRes.data.reports || []);
        setResumes(resumesRes.data.resumes || []);
      } catch {
        // silent
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  const latestReport = reports[0];
  const averageScore = reports.length > 0
    ? Math.round(reports.reduce((sum, r) => sum + (r.matchScore || 0), 0) / reports.length)
    : 0;

  const statCards = [
    { label: 'Avg Match Score', value: `${averageScore}%`, icon: Target, color: 'text-blue-600', bg: 'bg-blue-50' },
    { label: 'Total Reports', value: reports.length, icon: FileText, color: 'text-slate-700', bg: 'bg-slate-100' },
    { label: 'Resumes Saved', value: resumes.length, icon: BrainCircuit, color: 'text-emerald-600', bg: 'bg-emerald-50' },
    { label: 'ATS Readiness', value: latestReport ? `${latestReport.atsScore || 0}%` : '—', icon: TrendingUp, color: 'text-amber-600', bg: 'bg-amber-50' },
  ];

  return (
    <div className="space-y-8 animate-fade-in">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            Good {new Date().getHours() < 12 ? 'morning' : new Date().getHours() < 18 ? 'afternoon' : 'evening'}, {user?.name?.split(' ')[0] || 'there'}
          </h1>
          <p className="text-sm text-slate-500 mt-1">Here's an overview of your career activity.</p>
        </div>
        <Button variant="primary" icon={Zap} onClick={() => navigate('/analyze')}>New Analysis</Button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map((stat) => (
          <GlassCard key={stat.label} className="p-5 card-hover" hover>
            <div className="flex items-center gap-4">
              <div className={`w-10 h-10 rounded-xl ${stat.bg} flex items-center justify-center ${stat.color}`}>
                <stat.icon className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs text-slate-500 font-medium">{stat.label}</p>
                <p className="text-xl font-bold text-slate-900">{stat.value}</p>
              </div>
            </div>
          </GlassCard>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <GlassCard className="p-6 lg:col-span-2">
          <div className="flex items-center justify-between mb-5">
            <h3 className="text-sm font-semibold text-slate-900">Recent Reports</h3>
            {reports.length > 0 && (
              <button onClick={() => navigate('/reports')} className="text-xs text-blue-600 font-semibold hover:underline underline-offset-4">View all</button>
            )}
          </div>

          {loading ? (
            <div className="space-y-3">
              {[0,1,2,3,4].map((i) => <div key={i} className="skeleton h-12 w-full" />)}
            </div>
          ) : reports.length === 0 ? (
            <div className="text-center py-12">
              <div className="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center mx-auto mb-3">
                <FileText className="w-5 h-5 text-slate-400" />
              </div>
              <p className="text-sm text-slate-600 mb-4">No reports yet. Run your first analysis!</p>
              <Button variant="secondary" onClick={() => navigate('/analyze')}>Start Analysis</Button>
            </div>
          ) : (
            <div className="space-y-2">
              {reports.slice(0, 5).map((report) => (
                <div
                  key={report._id}
                  onClick={() => navigate(`/report/${report._id}`)}
                  className="flex items-center justify-between p-4 rounded-xl border border-slate-200 hover:border-slate-300 hover:bg-slate-50/60 transition-colors cursor-pointer"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center text-slate-700 font-bold text-xs flex-shrink-0">
                      {report.jobDescription?.charAt(0)?.toUpperCase() || 'R'}
                    </div>
                    <div className="min-w-0">
                      <p className="text-sm font-medium text-slate-900 truncate max-w-[240px]">{report.jobDescription?.substring(0, 50) || 'Untitled Report'}</p>
                      <p className="text-xs text-slate-500 mt-0.5">{new Date(report.generatedAt).toLocaleDateString()}</p>
                    </div>
                  </div>
                  <span className={`text-sm font-bold flex-shrink-0 ${
                    (report.matchScore || 0) >= 70 ? 'text-emerald-600' : (report.matchScore || 0) >= 50 ? 'text-amber-600' : 'text-red-600'
                  }`}>{report.matchScore}%</span>
                </div>
              ))}
            </div>
          )}
        </GlassCard>

        <GlassCard className="p-6">
          <h3 className="text-sm font-semibold text-slate-900 mb-4">Quick Actions</h3>
          <div className="space-y-2.5">
            {[
              { label: 'Analyze Resume', desc: 'Get ATS score & recommendations', icon: Target, path: '/analyze', accent: 'text-blue-600 bg-blue-50' },
              { label: 'View Reports', desc: `${reports.length} saved reports`, icon: FileText, path: '/reports', accent: 'text-slate-700 bg-slate-100' },
            ].map((action) => (
              <button
                key={action.label}
                onClick={() => navigate(action.path)}
                className="flex items-center gap-3.5 p-4 rounded-xl border border-slate-200 hover:border-slate-300 hover:bg-slate-50/60 transition-colors w-full text-left"
              >
                <span className={`inline-flex items-center justify-center w-9 h-9 rounded-lg ${action.accent}`}>
                  <action.icon className="w-4 h-4" />
                </span>
                <div>
                  <h4 className="text-sm font-semibold text-slate-900">{action.label}</h4>
                  <p className="text-xs text-slate-500 mt-0.5">{action.desc}</p>
                </div>
              </button>
            ))}
          </div>
        </GlassCard>
      </div>
    </div>
  );
};

export default DashboardHome;
