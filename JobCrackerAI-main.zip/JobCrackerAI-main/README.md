# JobCracker AI

A futuristic Career Operating System powered by Groq AI. Upload your resume, get deep ATS analytics, skill gap detection, and a personalized roadmap to your dream role.

## Tech Stack

- **Frontend**: React 19 + Vite + Tailwind CSS v4
- **Charts**: Recharts
- **Icons**: Lucide React
- **AI**: Groq SDK (Llama 3.3 70B)

## Getting Started

### 1. Clone and install

```bash
git clone <repo-url>
cd jobcracker-ai
npm install
```

### 2. Set up your Groq API key

1. Go to [console.groq.com](https://console.groq.com/keys) and create a free API key.
2. Copy `.env.example` to `.env`:
   ```bash
   cp .env.example .env
   ```
3. Replace `your_groq_api_key_here` with your actual key:
   ```
   VITE_GROQ_API_KEY=gsk_xxxxxxxxxxxxxxxxxxxxxxxx
   ```

### 3. Start the dev server

```bash
npm run dev
```

The app will be running at `http://localhost:5173`.

## Features

- **AI Resume Analyzer** — Paste your resume and a job description to get an ATS match score, skill gap analysis, and actionable recommendations.
- **AI Career Coach** — Chat with a Groq-powered assistant for interview prep, salary negotiation, and career advice.
- **Dashboard** — Overview of your job search activity, upcoming interviews, and stats.
- **Job Tracker** — Kanban-style pipeline to manage applications (wishlist → applied → interviewing).
- **Authentication UI** — Login/Signup interface (frontend-only, ready for backend integration).

## API Used

All AI features use the **Groq API** via the `groq-sdk` package. The model used is `llama-3.3-70b-versatile`. No server-side backend required — everything runs client-side via the Vite dev proxy or production build.

## Project Structure

```
src/
├── components/        # Shared UI components
│   ├── Button.jsx
│   ├── GlassCard.jsx
│   ├── GradientText.jsx
│   └── ParticleNetwork.jsx
├── services/          # API service layer
│   └── groq.js        # Groq API client (analyzeResume, chatWithCoach)
├── views/             # Page-level views
│   ├── LandingPage.jsx
│   ├── AuthPage.jsx
│   ├── AppShell.jsx   # Main app layout + navigation
│   ├── DashboardHome.jsx
│   ├── AnalyzerFlow.jsx
│   ├── TrackerView.jsx
│   └── ChatCoach.jsx
├── App.jsx            # Root component (routing logic)
├── App.css            # Legacy styles (unused)
├── main.jsx           # Entry point
└── index.css          # Tailwind import
```

## Build

```bash
npm run build
```

Output goes to `dist/` — deploy anywhere that serves static files.

## License

MIT
