
const ensureArray = (value) => {
  if (Array.isArray(value)) return value;
  if (typeof value !== 'string') return [];

  // Try standard JSON parse first
  try {
    const parsed = JSON.parse(value);
    if (Array.isArray(parsed)) return parsed;
  } catch {
  }

  try {
    let cleaned = value
      .replace(/^\[\s*'?\s*\+\s*'?\s*/g, '[')          // opening bracket
      .replace(/,?\s*'\s*\+\s*'\s*/g, ',')               // concatenation markers
      .replace(/\s*'?\s*\+\s*'?\s*\]$/g, ']')            // closing bracket
      .replace(/,(\s*[\]}])/g, '$1');                     // trailing commas

    const parsed = JSON.parse(cleaned);
    if (Array.isArray(parsed)) return parsed;
  } catch {
    // Still not valid — return empty array
  }

  return [];
};

const sanitizeReportData = (aiResult) => {
  const matchScore = Number(aiResult.matchScore) || 0;
  const atsScore = Number(aiResult.atsScore) || 0;

  // Ensure all array fields are real arrays
  const missingSkills = ensureArray(aiResult.missingSkills);
  const strengths = ensureArray(aiResult.strengths);
  const weaknesses = ensureArray(aiResult.weaknesses);
  const preparationPlan = ensureArray(aiResult.preparationPlan);
  const technicalQuestions = ensureArray(aiResult.technicalQuestions);
  const behavioralQuestions = ensureArray(aiResult.behavioralQuestions);

  return {
    matchScore,
    atsScore,
    missingSkills,
    strengths,
    weaknesses,
    preparationPlan,
    technicalQuestions,
    behavioralQuestions,
  };
};

export default sanitizeReportData;
