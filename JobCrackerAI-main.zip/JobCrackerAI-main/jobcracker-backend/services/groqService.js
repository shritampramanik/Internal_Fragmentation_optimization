import Groq from 'groq-sdk';

const groq = new Groq({
  apiKey: process.env.GROQ_API_KEY,
});

const generateATSReport = async (resumeText, jobDescription) => {
  const systemPrompt = `You are an expert ATS (Applicant Tracking System) analyzer and career coach.
Analyze the candidate's resume against the provided job description.

Return a JSON object with this exact structure:
{
  "matchScore": <number 0-100>,
  "atsScore": <number 0-100>,
  "missingSkills": [
    { "skill": "<skill name>", "match": <number 0-100> }
  ],
  "strengths": ["<strength 1>", "<strength 2>", ...],
  "weaknesses": ["<weakness 1>", "<weakness 2>", ...],
  "preparationPlan": [
    { "title": "<specific actionable recommendation>", "type": "<Resume Edit | Study Plan | Interview Prep>" }
  ],
  "technicalQuestions": ["<question 1>", "<question 2>", "<question 3>", "<question 4>"],
  "behavioralQuestions": ["<question 1>", "<question 2>", "<question 3>", "<question 4>"]
}

Rules:
- matchScore: Overall percentage match between resume and job description.
- atsScore: How well the resume would pass an ATS scan (keyword optimization, formatting, quantifiable achievements).
- missingSkills: Exactly 6 key skills from the job description with match percentages. Include both strong and weak matches.
- strengths: Exactly 4 points about what the candidate does well relative to this role.
- weaknesses: Exactly 4 points about gaps or areas to improve.
- preparationPlan: Exactly 5 actionable recommendations. Type must be: "Resume Edit", "Study Plan", or "Interview Prep".
- technicalQuestions: Exactly 4 technical interview questions tailored to this role.
- behavioralQuestions: Exactly 4 behavioral interview questions tailored to this role.
- Be honest, precise, and specific. Do not inflate scores.
- Keep every string under 20 words. Be dense and concrete — no filler, no restating the question.
- Return ONLY valid JSON. No markdown, no code blocks, no extra text.

CRITICAL: All array fields (missingSkills, strengths, weaknesses, preparationPlan, technicalQuestions, behavioralQuestions) must be actual JSON arrays — NOT stringified JSON, NOT template literals, NOT single-quoted strings. Use double quotes for all keys and string values.`;

  let completion;
  try {
    completion = await groq.chat.completions.create({
      model: 'qwen/qwen3.8-27b',
      messages: [
        { role: 'system', content: systemPrompt },
        {
          role: 'user',
          content: `RESUME:\n${resumeText}\n\nJOB DESCRIPTION:\n${jobDescription}`,
        },
      ],
      temperature: 0.3,
      max_tokens: 900,
      response_format: { type: 'json_object' },
    });
  } catch (err) {
    // Groq's free tier caps output tokens per minute; surface that as a retryable
    // 429 instead of a generic 500 with the raw upstream error text.
    if (err.status === 429) {
      const rateLimitError = new Error(
        'The AI service is busy right now (rate limit reached). Please try again in a minute.'
      );
      rateLimitError.statusCode = 429;
      throw rateLimitError;
    }
    throw err;
  }

  const content = completion.choices[0]?.message?.content;
  if (!content) throw new Error('No response from Groq API');

  try {
    const result = JSON.parse(content);

    // Post-process: ensure all array fields are actual arrays
    // Groq sometimes returns stringified JSON or template literals
    const arrayFields = ['missingSkills', 'strengths', 'weaknesses', 'preparationPlan', 'technicalQuestions', 'behavioralQuestions'];
    for (const field of arrayFields) {
      if (typeof result[field] === 'string') {
        // Try to parse stringified array
        try {
          const parsed = JSON.parse(result[field]);
          if (Array.isArray(parsed)) {
            result[field] = parsed;
          } else {
            result[field] = [];
          }
        } catch {
          // If it's a template literal or garbage, fallback to empty array
          result[field] = [];
        }
      } else if (!Array.isArray(result[field])) {
        result[field] = [];
      }
    }

    return result;
  } catch {
    throw new Error('Failed to parse AI analysis response');
  }
};

export default generateATSReport;
