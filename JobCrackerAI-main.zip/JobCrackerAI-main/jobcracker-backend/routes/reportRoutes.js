import { Router } from 'express';
import { generateReport, getReport, getReportHistory } from '../controllers/reportController.js';
import protect from '../middleware/auth.js';

const router = Router();

router.use(protect);

router.post('/generate', generateReport);
router.get('/history', getReportHistory);
router.get('/:id', getReport);

export default router;
