import { Router } from 'express';
import { guestUpload, guestReport } from '../controllers/guestController.js';

const router = Router();

router.post('/report', guestUpload, guestReport);

export default router;
