import { Router } from 'express';
import { upload, uploadResume, getResumeHistory } from '../controllers/resumeController.js';
import protect from '../middleware/auth.js';

const router = Router();

router.use(protect);

router.post('/upload', upload, uploadResume);
router.get('/history', getResumeHistory);

export default router;
