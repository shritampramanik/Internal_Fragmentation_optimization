import Report from '../models/Report.js';
import Resume from '../models/Resume.js';
import sanitizeReportData from '../utils/sanitizeAIResult.js';

// GET /api/report/:id
export const getReport = async (req, res) => {
  try {
    const report = await Report.findById(req.params.id).populate('resume');

    if (!report) {
      return res.status(404).json({ success: false, message: 'Report not found' });
    }

    if (report.user.toString() !== req.user._id.toString()) {
      return res.status(403).json({ success: false, message: 'Not authorized' });
    }

    res.json({ success: true, data: { report } });
  } catch (error) {
    res.status(error.statusCode || 500).json({ success: false, message: error.message });
  }
};

// GET /api/report/history
export const getReportHistory = async (req, res) => {
  try {
    const reports = await Report.find({ user: req.user._id })
      .populate('resume', 'filename')
      .sort({ generatedAt: -1 })
      .limit(30);

    res.json({ success: true, data: { reports } });
  } catch (error) {
    res.status(error.statusCode || 500).json({ success: false, message: error.message });
  }
};

// POST /api/report/generate
export const generateReport = async (req, res) => {
  try {
    const { resumeId, jobDescription } = req.body;

    if (!resumeId || !jobDescription) {
      return res.status(400).json({ success: false, message: 'Resume ID and job description are required' });
    }

    const resume = await Resume.findById(resumeId);
    if (!resume) {
      return res.status(404).json({ success: false, message: 'Resume not found' });
    }

    if (resume.user.toString() !== req.user._id.toString()) {
      return res.status(403).json({ success: false, message: 'Not authorized' });
    }

    const generateATSReport = (await import('../services/groqService.js')).default;
    const aiResult = await generateATSReport(resume.extractedText, jobDescription);
    const sanitized = sanitizeReportData(aiResult);

    const report = await Report.create({
      user: req.user._id,
      resume: resume._id,
      jobDescription,
      ...sanitized,
    });

    res.status(201).json({
      success: true,
      data: { report },
    });
  } catch (error) {
    res.status(error.statusCode || 500).json({ success: false, message: error.message });
  }
};
