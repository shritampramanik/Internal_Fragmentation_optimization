import multer from 'multer';
import pdfParse from 'pdf-parse';

// Multer config — store PDF in memory for guest
const storage = multer.memoryStorage();
const fileFilter = (req, file, cb) => {
  if (file.mimetype === 'application/pdf') {
    cb(null, true);
  } else {
    cb(new Error('Only PDF files are allowed'), false);
  }
};

export const guestUpload = multer({
  storage,
  fileFilter,
  limits: { fileSize: 5 * 1024 * 1024 },
}).single('resume');

// Helper: ensures a value is a proper array (Groq sometimes returns stringified JSON)
const ensureArray = (value) => {
  if (Array.isArray(value)) return value;
  if (typeof value === 'string') {
    try { const parsed = JSON.parse(value); return Array.isArray(parsed) ? parsed : []; } catch { return []; }
  }
  return [];
};

// POST /api/guest/report
export const guestReport = async (req, res) => {
  try {
    const { jobDescription } = req.body;

    if (!req.file) {
      return res.status(400).json({ success: false, message: 'No PDF resume uploaded' });
    }

    if (!jobDescription || jobDescription.trim().length < 20) {
      return res.status(400).json({ success: false, message: 'Job description is required (minimum 20 characters)' });
    }

    // Parse PDF
    const pdfData = await pdfParse(req.file.buffer);
    const extractedText = pdfData.text;

    if (!extractedText || extractedText.trim().length < 50) {
      return res.status(400).json({ success: false, message: 'Could not extract sufficient text from the PDF' });
    }

    const generateATSReport = (await import('../services/groqService.js')).default;
    const aiResult = await generateATSReport(extractedText, jobDescription.trim());

    // Return report without saving to DB
    res.json({
      success: true,
      data: {
        report: {
          matchScore: Number(aiResult.matchScore) || 0,
          atsScore: Number(aiResult.atsScore) || 0,
          missingSkills: ensureArray(aiResult.missingSkills),
          strengths: ensureArray(aiResult.strengths),
          weaknesses: ensureArray(aiResult.weaknesses),
          preparationPlan: ensureArray(aiResult.preparationPlan),
          technicalQuestions: ensureArray(aiResult.technicalQuestions),
          behavioralQuestions: ensureArray(aiResult.behavioralQuestions),
          jobDescription: jobDescription.trim(),
          generatedAt: new Date(),
        },
      },
    });
  } catch (error) {
    res.status(error.statusCode || 500).json({ success: false, message: error.message });
  }
};
