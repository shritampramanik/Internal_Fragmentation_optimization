import multer from 'multer';
import pdfParse from 'pdf-parse';
import Resume from '../models/Resume.js';

// Multer config — store PDF in memory
const storage = multer.memoryStorage();
const fileFilter = (req, file, cb) => {
  if (file.mimetype === 'application/pdf') {
    cb(null, true);
  } else {
    cb(new Error('Only PDF files are allowed'), false);
  }
};

export const upload = multer({
  storage,
  fileFilter,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB
}).single('resume');

// POST /api/resume/upload
export const uploadResume = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ success: false, message: 'No file uploaded' });
    }

    // Parse PDF
    const pdfData = await pdfParse(req.file.buffer);
    const extractedText = pdfData.text;

    if (!extractedText || extractedText.trim().length < 50) {
      return res.status(400).json({ success: false, message: 'Could not extract sufficient text from the PDF' });
    }

    const resume = await Resume.create({
      user: req.user._id,
      filename: req.file.originalname,
      extractedText,
    });

    res.status(201).json({
      success: true,
      data: { resume },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// GET /api/resume/history
export const getResumeHistory = async (req, res) => {
  try {
    const resumes = await Resume.find({ user: req.user._id })
      .sort({ uploadedAt: -1 })
      .limit(20);

    res.json({
      success: true,
      data: { resumes },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};
