import mongoose from 'mongoose';

const reportSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  resume: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Resume',
    required: true,
  },
  jobDescription: {
    type: String,
    required: true,
  },
  matchScore: {
    type: Number,
    required: true,
    min: 0,
    max: 100,
  },
  atsScore: {
    type: Number,
    min: 0,
    max: 100,
  },
  missingSkills: {
    type: mongoose.Schema.Types.Mixed,
    default: [],
  },
  strengths: {
    type: mongoose.Schema.Types.Mixed,
    default: [],
  },
  weaknesses: {
    type: mongoose.Schema.Types.Mixed,
    default: [],
  },
  preparationPlan: {
    type: mongoose.Schema.Types.Mixed,
    default: [],
  },
  technicalQuestions: {
    type: mongoose.Schema.Types.Mixed,
    default: [],
  },
  behavioralQuestions: {
    type: mongoose.Schema.Types.Mixed,
    default: [],
  },
  generatedAt: {
    type: Date,
    default: Date.now,
  },
}, {
  timestamps: true,
});

const Report = mongoose.model('Report', reportSchema);

export default Report;
